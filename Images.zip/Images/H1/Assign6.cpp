//Quick sort


#include<bits/stdc++.h>
#include<omp.h>
using namespace std;

int partition(vector<int>& arr, int l, int r)
{
    int pivot=arr[l];
    int i=l;
    int j=r;
    while(i<j)
    {
        while(arr[i]<=pivot && i<r)
        {
            i++;
        }
        while(arr[j]>pivot && j>=l+1)
        {
            j--;
        }
        if(i<j)
        {
            swap(arr[i],arr[j]);
        }
    }
    swap(arr[l],arr[j]);
    return j;
}

void sequential(vector<int>& arr, int l, int r)
{
    if (l<r)
    {
        int pIdx=partition(arr,l, r);
        sequential(arr,l,pIdx-1);
        sequential(arr,pIdx+1,r);
    }
}

void parallel(vector<int>& arr_cpy, int l, int r)
{
    if (l<r)
    {
        int pIdx=partition(arr_cpy,l,r);

        #pragma omp task shared(arr_cpy)
        parallel(arr_cpy,l,pIdx-1);

        #pragma omp task shared(arr_cpy)
        parallel(arr_cpy,pIdx+1,r);
    }
}

int main()
{
    int n;
    cout<<"\nEnter the number of elements : ";
    cin>>n;
    vector<int>arr(n),arr_cpy(n);

    for(int i=0;i<n;i++)
    {
        arr[i]=rand()%n;
        cout<<arr[i]<<"  ";
    }

    arr_cpy=arr;

    double seq_time=omp_get_wtime();
    sequential(arr,0,n-1);
    double end_time=omp_get_wtime();
    cout<<"\nTime taken by sequential : "<<(end_time-seq_time);

    cout<<"\nSequential output "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<"  ";
    }

    double seq_time1=omp_get_wtime();
    parallel(arr_cpy,0,n-1);
    double end_time1=omp_get_wtime();
    cout<<"\nTime taken by Parallel : "<<(end_time1-seq_time1);
    cout<<"\nParallel output "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr_cpy[i]<<"  ";
    }
    
}