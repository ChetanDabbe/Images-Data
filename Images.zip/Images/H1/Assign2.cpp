//Depth first Search

#include<bits/stdc++.h>
#include<omp.h>

using namespace std;

void dfs(vector<vector<int>>& arr, vector<int>&visited, int start,int n)
{
    #pragma omp critical
    {
        if (visited[start]) return;
        visited[start]=1;
        cout<<start<<"  ";
    }

    for(int i=0;i<n;i++)
    {

        if (arr[start][i]==1)
        {
            #pragma omp task
            dfs(arr,visited,i,n);
        }
    }
    #pragma omp taskwait
}


int main()
{
    int n;
    cout<<"\nEnter the number of vertices : ";
    cin>>n;
    srand(time(0));
    int u, v;
    vector<vector<int>>arr(n,vector<int>(n,0));
    vector<int>visited(n,0);
    char ch,ch1;
    do{
        // u=rand()%n;
        // v=rand()%n;

        // if(u!=v)
        // {
        //     arr[u][v]=1;
        //     arr[v][u]=1;
        // }
        // else{
        //     cout<<"\nEnter correct source and destination";
        // }
        cout<<"\nEnter the edge : ";
        cin>>u>>v;
        arr[u][v]=1;
        arr[v][u]=1;
        cout<<"\nDo you want to continue (Y/N) : ";
        cin>>ch;
    }while(ch=='y' || ch=='Y');

    int start;
    cout<<"\nEnter the starting vertex : ";
    cin>>start;
    #pragma omp parallel
    {
        #pragma omp single
        dfs(arr,visited,start,n);
    }
    
}