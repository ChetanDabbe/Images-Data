//Matrix Vector Multiplication

#include<bits/stdc++.h>
#include<omp.h>
using namespace std;


void display_matrix(vector<vector<int>>& arr)
{
    for(int i=0;i<arr.size();i++)
    {
        for(int j=0;j<arr[0].size();j++)
        {
            cout<<arr[i][j]<<"  ";
        }
        cout<<endl;
    }
}

void display_vector(vector<int>& vec)
{
    for(int i=0;i<vec.size();i++)
    {
        cout<<vec[i]<<"  ";
    }
}
void initialize_matrix(vector<vector<int>>& arr)
{
    for(int i=0;i<arr.size();i++)
    {
        for(int j=0;j<arr[0].size();j++)
        {
            arr[i][j]=rand()%10;
        }
    }
    cout<<"\nMatrix "<<endl;
    display_matrix(arr);
}

void initialize_vector(vector<int>& vec)
{
    for(int i=0;i<vec.size();i++)
    {
        vec[i]=rand()%10;
    }
    cout<<"\nVector : "<<endl;
    display_vector(vec);
}



void multiplication(vector<vector<int>>&arr, vector<int>&vec, vector<int>& result)
{
    #pragma omp parallel for
    for(int i=0;i<arr.size();i++)
    {
        result[i]=0;
        for(int j=0;j<arr[0].size();j++)
        {
            result[i]+=arr[i][j]*vec[j];
        }
    }

    display_vector(result);
}

int main()
{
    int rows, cols;
    cout<<"\nEnter the rows and columns : ";
    cin>>rows>>cols;

    vector<vector<int>>arr(rows, vector<int>(cols));
    vector<int>vec(cols,0);

    vector<int>result(cols);

    initialize_matrix(arr);
    initialize_vector(vec);

    cout<<"\noutput "<<endl;
    multiplication(arr,vec,result);

}