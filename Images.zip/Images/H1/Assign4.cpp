//Bubble sort

#include<bits/stdc++.h>
#include<omp.h>
using namespace std;


void sequential(vector<int>& arr, int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if (arr[j]>arr[j+1])
                swap(arr[j], arr[j+1]);
        }
    }
}

void parallel(vector<int>&arr_cpy, int n)
{
    for(int i=0;i<n;i++)
    {
        #pragma omp parallel for 
        for(int j=0;j<n-1;j+=2)
        {
            if (arr_cpy[j]>arr_cpy[j+1])
                swap(arr_cpy[j], arr_cpy[j+1]);
        }

        #pragma omp parallel for
        for (int j=1;j<n-1;j+=2)
        {
            if(arr_cpy[j]>arr_cpy[j+1])
                swap(arr_cpy[j],arr_cpy[j+1]);
        }
    }
}

int main()
{
    int n;
    cout<<"\nEnter the number of elements : ";
    cin>>n;
    vector<int>arr(n),arr_cpy(n);

    for(int i=0;i<n;i++)
    {
        arr[i]=rand()%n;
        cout<<arr[i]<<"  ";
    }

    arr_cpy=arr;

    double seq_time=omp_get_wtime();
    sequential(arr,n);
    double end_time=omp_get_wtime();
    cout<<"\nTime taken by sequential : "<<(end_time-seq_time);

    cout<<"\nSequential output "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<"  ";
    }

    double seq_time1=omp_get_wtime();
    parallel(arr_cpy,n);
    double end_time1=omp_get_wtime();
    cout<<"\nTime taken by Parallel : "<<(end_time1-seq_time1);
    cout<<"\nParallel output "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr_cpy[i]<<"  ";
    }
    
}