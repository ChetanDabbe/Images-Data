//Matrix multiplication

#include<bits/stdc++.h>
#include<omp.h>
using namespace std;


void initialize_matrix(vector<vector<int>>&matrix)
{
    for(int i=0;i<matrix.size();i++)
    {
        for(int j=0;j<matrix[0].size();j++)
        {
            matrix[i][j]=rand()%100;
        }
    }
}

void display(vector<vector<int>>& matrix)
{
    for(int i=0;i<matrix.size();i++)
    {
        for(int j=0;j<matrix[0].size();j++)
        {
            cout<<matrix[i][j]<<"  ";
        }
        cout<<endl;
    }
}


void multiplication(vector<vector<int>>&A, vector<vector<int>>&B, vector<vector<int>>&result)
{
    int m=A.size();
    int n=A[0].size();
    int l=B[0].size();

    #pragma omp parallel for collapse(2)
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<l;j++)
        {
            for(int k=0;k<n;k++)
            {
                result[i][j]+=A[i][k]*B[k][j];
            }
        }
    }

    display(result);
}
int main()
{
    int rows,cols, cols2;

    cout<<"\nEnter the rows & cols for matrix A : ";
    cin>>rows>>cols;

    cout<<"\nEnter the cols for matrix B : ";
    cin>>cols2;

    vector<vector<int>>A(rows, vector<int>(cols));
    vector<vector<int>>B(cols, vector<int>(cols2));
    vector<vector<int>>result(rows, vector<int>(cols2));

    initialize_matrix(A);
    initialize_matrix(B);

    cout<<endl<<endl;
    display(A);
    cout<<endl<<endl;
    display(B);

    cout<<endl;
    multiplication(A,B, result);

}