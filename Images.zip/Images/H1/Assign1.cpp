// Breadth First Search

#include <bits/stdc++.h>
#include <omp.h>
using namespace std;

void bfs(vector<vector<int>> &arr, int start, int n)
{
    vector<int> visited(n);
    queue<int> q;
    visited[start] = 1;
    q.push(start);

    while (!q.empty())
    {
        int curr = q.front();
        q.pop();

        cout << curr << "  ";

#pragma omp parallel for
        for (int i = 0; i < n; i++)
        {
#pragma omp critical
            {
                if (arr[curr][i] == 1)
                {
                    if (visited[i] == 0)
                    {
                        visited[i] = 1;
                        q.push(i);
                    }
                }
            }
        }
    }
}

int main()
{
    int n;
    cout << "\nEnter number of vertices : ";
    cin >> n;
    int u, v;
    char ch;
    vector<vector<int>> arr(n, vector<int>(n, 0));
    do
    {
        u = rand() % n;
        v = rand() % n;

        if (u != v)
        {
            arr[u][v] = 1;
            arr[v][u] = 1;
        }
        else
        {
            cout << "\nPlease enter correct source and destination" << endl;
        }
        cout << "\nDo you want to add more edges (Y/N) : ";
        cin>>ch;
    } while (ch == 'y' || ch == 'Y');

    cout << "\nAdjacency matrix : " << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << arr[i][j] << "  ";
        }
        cout << endl;
    }

    int a;
    char ch1;
    do{
        cout<<"\nEnter starting vertex : ";
        cin>>a;
        bfs(arr,a,n);
        cout<<"\nDo you want to check for another vertex ";
        cin>>ch;
    }while(ch=='y' || ch=='Y');
}