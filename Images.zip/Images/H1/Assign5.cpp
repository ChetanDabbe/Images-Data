//Merge sort
#include<bits/stdc++.h>
#include<omp.h>
using namespace std;

void merge(vector<int>& arr, int l, int m, int r)
{
    vector<int>result(r-l+1);
    int i=l;
    int j=m+1;
    int k=0;

    while(i<=m && j<=r)
    {
        if (arr[i]<arr[j])
        {
            result[k++]=arr[i++];
        }
        else{
            result[k++]=arr[j++];
        }
    }
    while(i<=m)
    {
        result[k++]=arr[i++];
    }
    while(j<=r)
    {
        result[k++]=arr[j++];
    }

    for(int i=l,k=0;i<=r;i++,k++)
    {
        arr[i]=result[k];
    }
}

void sequential(vector<int>& arr, int l, int r)
{
    if (l<r)
    {
        int m = (l+r)/2;
        sequential(arr,l,m);
        sequential(arr,m+1,r);
        merge(arr,l,m,r);
    }
}

void parallel(vector<int>& arr_cpy, int l, int r)
{
    if (l<r)
    {
        int m=(l+r)/2;

        #pragma omp parallel sections
        {
            #pragma omp section
            parallel(arr_cpy, l, m);

            #pragma omp section
            parallel(arr_cpy,m+1,r);
        }

        merge(arr_cpy,l,m,r);
    }
}

int main()
{
    int n;
    cout<<"\nEnter the number of elements : ";
    cin>>n;
    vector<int>arr(n),arr_cpy(n);

    for(int i=0;i<n;i++)
    {
        arr[i]=rand()%n;
        cout<<arr[i]<<"  ";
    }

    arr_cpy=arr;

    double seq_time=omp_get_wtime();
    sequential(arr,0,n-1);
    double end_time=omp_get_wtime();
    cout<<"\nTime taken by sequential : "<<(end_time-seq_time);

    cout<<"\nSequential output "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<"  ";
    }

    double seq_time1=omp_get_wtime();
    parallel(arr_cpy,0,n-1);
    double end_time1=omp_get_wtime();
    cout<<"\nTime taken by Parallel : "<<(end_time1-seq_time1);
    cout<<"\nParallel output "<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<arr_cpy[i]<<"  ";
    }
    
}