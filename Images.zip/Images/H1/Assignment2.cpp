#include<bits/stdc++.h>
#include<omp.h>
using namespace std;

void dfs(vector<vector<int>>& arr, vector<int>& visited, int start, int n) {
    // Check and mark visited atomically
    bool doVisit = false;
    #pragma omp critical
    {
        if (!visited[start]) {
            visited[start] = 1;
            cout << start << " ";
            doVisit = true;
        }
    }

    if (!doVisit) return;

    for (int i = 0; i < n; i++) {
        if (arr[start][i] == 1) {
            // Spawn task to visit unvisited neighbors
            #pragma omp task
            dfs(arr, visited, i, n);
        }
    }

    #pragma omp taskwait
}

int main() {
    int n, u, v;
    cout << "\nEnter the number of vertices : ";
    cin >> n;

    vector<vector<int>> arr(n, vector<int>(n, 0));
    vector<int> visited(n, 0);

    char ch;
    do {
        cout << "\nEnter the edge : ";
        cin >> u >> v;
        arr[u][v] = arr[v][u] = 1;
        cout << "\nDo you want to continue(Y/N) : ";
        cin >> ch;
    } while (ch == 'y' || ch == 'Y');

    int start;
    cout << "\nEnter the starting vertex : ";
    cin >> start;

    #pragma omp parallel
    {
        #pragma omp single
        dfs(arr, visited, start, n);
    }

    return 0;
}
